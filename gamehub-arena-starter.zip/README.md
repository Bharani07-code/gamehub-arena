# GameHub Arena

A React + Vite starter for an all-in-one competitive gaming app.

Included in this MVP:
- Home dashboard
- Player profile
- Local leaderboard
- Tic-Tac-Toe playable game
- XP and rating updates after a win
- Responsive mobile-friendly UI
- LocalStorage persistence

Run:
1. Install Node.js
2. In this folder run: npm install
3. Run: npm run dev
4. Open the local URL shown by Vite

Planned next:
- Firebase/Supabase authentication
- Real-time online matchmaking
- Chess
- Daily puzzles
- Friend challenges
- Global leaderboard
- Tournaments and seasons
